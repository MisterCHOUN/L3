class Main
{
	public static void main (String[] args)
	{
		System.out.println("Hello World");

		Fraction frac = new Fraction(12, 4);

		System.out.println(frac + " = " + frac.getValue());
	}
}